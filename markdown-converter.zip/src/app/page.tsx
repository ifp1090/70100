'use client'
import { useState, useRef, useEffect } from 'react'
import dynamic from 'next/dynamic'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Slider } from '@/components/ui/slider'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2 } from 'lucide-react'
import { generatePDF, generateDOCX } from '@/lib/document-generator'

// 动态导入Markdown编辑器组件以避免SSR问题
const MDEditor = dynamic(() => import('@uiw/react-md-editor').then(mod => mod.default), { 
  ssr: false,
  loading: () => <div className="h-[400px] flex items-center justify-center">加载编辑器中...</div>
});

// 动态导入预览组件
const Markdown = dynamic(() => import('react-markdown'), { ssr: false });
const rehypeKatex = dynamic(() => import('rehype-katex'), { ssr: false });
const remarkMath = dynamic(() => import('remark-math'), { ssr: false });
const remarkGfm = dynamic(() => import('remark-gfm'), { ssr: false });
const rehypeRaw = dynamic(() => import('rehype-raw'), { ssr: false });

export default function Home() {
  const [markdown, setMarkdown] = useState<string>('# 欢迎使用Markdown转换器\n\n在这里编辑您的Markdown内容，支持从其他编辑器（如Typora）粘贴内容。\n\n## 支持的功能\n\n- **外链图片**：![示例图片](https://picsum.photos/200/100)\n- **数学公式**：$E = mc^2$\n- **表格**：\n\n| 标题 | 描述 |\n| ---- | ---- |\n| 项目1 | 描述1 |\n| 项目2 | 描述2 |');
  const [activeTab, setActiveTab] = useState<string>('edit');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [previewScale, setPreviewScale] = useState<number>(1);
  const [pdfUrl, setPdfUrl] = useState<string>('');
  const [docxUrl, setDocxUrl] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [generationProgress, setGenerationProgress] = useState<string>('');
  const previewRef = useRef<HTMLDivElement>(null);
  
  // 清理URL对象，防止内存泄漏
  useEffect(() => {
    return () => {
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
      if (docxUrl) URL.revokeObjectURL(docxUrl);
    };
  }, [pdfUrl, docxUrl]);
  
  // 处理编辑器内容变化
  const handleEditorChange = (value?: string) => {
    if (value !== undefined) {
      setMarkdown(value);
    }
  };
  
  // 切换到预览模式
  const handlePreview = () => {
    setActiveTab('preview');
  };
  
  // 切换回编辑模式
  const handleEdit = () => {
    setActiveTab('edit');
  };
  
  // 处理预览缩放
  const handleScaleChange = (value: number[]) => {
    setPreviewScale(value[0]);
  };
  
  // 生成文档（PDF和DOCX）
  const handleGenerate = async () => {
    setIsGenerating(true);
    setError('');
    setGenerationProgress('正在准备生成文档...');
    
    try {
      // 生成PDF
      setGenerationProgress('正在生成PDF文档...');
      const pdfBlobUrl = await generatePDF(markdown, previewRef);
      setPdfUrl(pdfBlobUrl);
      
      // 生成DOCX
      setGenerationProgress('正在生成DOCX文档...');
      const docxBlobUrl = await generateDOCX(markdown, previewRef);
      setDocxUrl(docxBlobUrl);
      
      setGenerationProgress('文档生成完成！');
      
      // 切换到下载选项卡
      setActiveTab('download');
    } catch (error) {
      console.error('文档生成失败:', error);
      setError('文档生成失败，请确保预览内容正确显示后重试');
    } finally {
      setIsGenerating(false);
      setGenerationProgress('');
    }
  };

  // 下载PDF文件
  const handleDownloadPDF = () => {
    if (!pdfUrl) return;
    
    const link = document.createElement('a');
    link.href = pdfUrl;
    link.download = 'document.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // 下载DOCX文件
  const handleDownloadDOCX = () => {
    if (!docxUrl) return;
    
    const link = document.createElement('a');
    link.href = docxUrl;
    link.download = 'document.docx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <main className="flex min-h-screen flex-col items-center p-4 sm:p-8 bg-gray-50">
      <div className="w-full max-w-4xl">
        <header className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-3">Markdown转换器</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            将Markdown文件转换为固定大小(70mm×100mm)的PDF或Word文档。支持从其他编辑器（如Typora）粘贴内容，支持外链图片和数学公式。
          </p>
        </header>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="edit" className="text-sm sm:text-base">编辑</TabsTrigger>
            <TabsTrigger value="preview" className="text-sm sm:text-base">预览</TabsTrigger>
            <TabsTrigger value="download" className="text-sm sm:text-base">下载</TabsTrigger>
          </TabsList>
          
          <TabsContent value="edit">
            <Card className="p-4 shadow-md">
              <div data-color-mode="light">
                <MDEditor
                  value={markdown}
                  onChange={handleEditorChange}
                  height={500}
                  preview="edit"
                />
              </div>
              <div className="flex justify-end mt-4">
                <Button onClick={handlePreview} className="bg-blue-600 hover:bg-blue-700">
                  预览文档
                </Button>
              </div>
            </Card>
          </TabsContent>
          
          <TabsContent value="preview">
            <Card className="p-4 shadow-md">
              <div className="preview-scale-control">
                <div className="flex items-center justify-center mb-2">
                  <span className="mr-2 text-sm">缩放预览:</span>
                  <div className="w-64">
                    <Slider
                      defaultValue={[1]}
                      min={0.5}
                      max={2}
                      step={0.1}
                      value={[previewScale]}
                      onValueChange={handleScaleChange}
                    />
                  </div>
                  <span className="ml-2 text-sm">{(previewScale * 100).toFixed(0)}%</span>
                </div>
                <p className="text-xs text-center text-gray-500 mb-4">
                  预览尺寸: 70mm × 100mm (实际输出大小)
                </p>
              </div>
              
              <div className="flex justify-center">
                <div 
                  ref={previewRef}
                  style={{
                    transform: `scale(${previewScale})`,
                    transformOrigin: 'top center',
                    marginBottom: `${(previewScale - 1) * 100}mm`
                  }}
                >
                  <div className="preview-container">
                    {/* 预览内容 */}
                    <div data-color-mode="light">
                      <Markdown
                        remarkPlugins={[remarkMath, remarkGfm]}
                        rehypePlugins={[rehypeKatex, rehypeRaw]}
                      >
                        {markdown}
                      </Markdown>
                    </div>
                  </div>
                </div>
              </div>
              
              {error && (
                <Alert variant="destructive" className="mt-4">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              {isGenerating && (
                <div className="flex flex-col items-center justify-center mt-4 p-4 bg-gray-50 rounded-md">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-600 mb-2" />
                  <p className="text-sm text-gray-600">{generationProgress || '正在生成文档...'}</p>
                </div>
              )}
              
              <div className="flex justify-between mt-4">
                <Button variant="outline" onClick={handleEdit}>
                  返回编辑
                </Button>
                <Button 
                  onClick={handleGenerate} 
                  disabled={isGenerating}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isGenerating ? '生成中...' : '生成文档'}
                </Button>
              </div>
            </Card>
          </TabsContent>
          
          <TabsContent value="download">
            <Card className="p-6 shadow-md">
              <div className="text-center mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto text-green-500 mb-2">
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                  <polyline points="22 4 12 14.01 9 11.01"></polyline>
                </svg>
                <h2 className="text-2xl font-bold mb-2">文档已生成</h2>
                <p className="text-gray-600">您的Markdown文档已成功转换为以下格式：</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="flex flex-col items-center p-6 border rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow">
                  <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-500 mb-3">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="16" y1="13" x2="8" y2="13"></line>
                    <line x1="16" y1="17" x2="8" y2="17"></line>
                    <polyline points="10 9 9 9 8 9"></polyline>
                  </svg>
                  <h3 className="text-lg font-medium mb-1">PDF文档</h3>
                  <p className="text-sm text-gray-500 mb-4">固定大小: 70mm × 100mm</p>
                  <Button 
                    onClick={handleDownloadPDF} 
                    disabled={!pdfUrl}
                    className="bg-red-500 hover:bg-red-600 text-white"
                  >
                    下载PDF
                  </Button>
                </div>
                
                <div className="flex flex-col items-center p-6 border rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow">
                  <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500 mb-3">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="16" y1="13" x2="8" y2="13"></line>
                    <line x1="16" y1="17" x2="8" y2="17"></line>
                    <polyline points="10 9 9 9 8 9"></polyline>
                  </svg>
                  <h3 className="text-lg font-medium mb-1">Word文档</h3>
                  <p className="text-sm text-gray-500 mb-4">固定大小: 70mm × 100mm</p>
                  <Button 
                    onClick={handleDownloadDOCX} 
                    disabled={!docxUrl}
                    className="bg-blue-500 hover:bg-blue-600 text-white"
                  >
                    下载DOCX
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-center">
                <Button variant="outline" onClick={handleEdit} className="mr-2">
                  返回编辑
                </Button>
                <Button onClick={handlePreview} variant="outline">
                  返回预览
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
        
        <footer className="mt-8 text-center text-sm text-gray-500">
          <p>© 2025 Markdown转换器 - 将Markdown转换为固定大小的PDF和Word文档</p>
        </footer>
      </div>
    </main>
  )
}
