'use client'

import { useRef } from 'react';
import { jsPDF } from 'jspdf';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, ImageRun, Table, TableRow, TableCell, BorderStyle, WidthType, AlignmentType } from 'docx';
import { renderToString } from 'react-dom/server';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import remarkGfm from 'remark-gfm';
import rehypeKatex from 'rehype-katex';
import rehypeRaw from 'rehype-raw';
import html2canvas from 'html2canvas';

// 将毫米转换为磅（用于DOCX）
const mmToPt = (mm: number) => mm * 2.83465;

// 将毫米转换为像素（假设96 DPI）
const mmToPx = (mm: number) => mm * 3.779528;

// PDF生成函数 - 使用HTML渲染方式
export const generatePDF = async (markdownContent: string, previewRef: React.RefObject<HTMLDivElement>): Promise<string> => {
  if (!previewRef.current) {
    throw new Error('预览元素不存在');
  }

  // 创建PDF文档，设置单位为毫米
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: [70, 100]
  });
  
  // 使用html2canvas捕获预览区域
  const canvas = await html2canvas(previewRef.current.querySelector('.preview-container') as HTMLElement, {
    scale: 2, // 提高分辨率
    useCORS: true, // 允许加载跨域图片
    logging: false,
    allowTaint: true,
    backgroundColor: '#ffffff'
  });
  
  // 将canvas转换为图片
  const imgData = canvas.toDataURL('image/png');
  
  // 将图片添加到PDF
  doc.addImage(imgData, 'PNG', 0, 0, 70, 100);
  
  // 保存PDF为Blob URL
  const pdfBlob = doc.output('blob');
  return URL.createObjectURL(pdfBlob);
};

// DOCX生成函数 - 使用预览区域截图方式
export const generateDOCX = async (markdownContent: string, previewRef: React.RefObject<HTMLDivElement>): Promise<string> => {
  if (!previewRef.current) {
    throw new Error('预览元素不存在');
  }

  // 使用html2canvas捕获预览区域
  const canvas = await html2canvas(previewRef.current.querySelector('.preview-container') as HTMLElement, {
    scale: 2, // 提高分辨率
    useCORS: true, // 允许加载跨域图片
    logging: false,
    allowTaint: true,
    backgroundColor: '#ffffff'
  });
  
  // 将canvas转换为图片数据
  const imgData = canvas.toDataURL('image/png');
  
  // 创建一个包含图片的DOCX文档
  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            size: {
              width: mmToPt(70),
              height: mmToPt(100),
            },
            margin: {
              top: 0,
              right: 0,
              bottom: 0,
              left: 0,
            },
          },
        },
        children: [
          new Paragraph({
            children: [
              new ImageRun({
                data: Buffer.from(imgData.split(',')[1], 'base64'),
                transformation: {
                  width: mmToPt(70),
                  height: mmToPt(100),
                },
              }),
            ],
          }),
        ],
      },
    ],
  });

  // 生成DOCX文件
  const buffer = await Packer.toBuffer(doc);
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  return URL.createObjectURL(blob);
};
